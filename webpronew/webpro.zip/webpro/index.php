<?php
$bilangan = 10;
    
if ($bilangan % 2 == 0) {
    echo "$bilangan adalah bilangan genap";
} else {
    echo "$bilangan adalah bilangan ganjil";
};

?>