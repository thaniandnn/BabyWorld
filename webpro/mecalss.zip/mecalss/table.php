<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Mahasiswa</title>
</head>

<body>
    <table border="1">
        <tr>
            <th>no</th>
            <th>NIM</th>
            <th>Nama Lengkap</th>
            <th>Jenis Kelamin</th>
            <th>Program Studi</th>
            <th>Alamat</th>
        </tr>
    </table>
</body>

</html>